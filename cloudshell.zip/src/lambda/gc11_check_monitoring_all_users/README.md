_This readme file was created by AWS Bedrock: anthropic.claude-v2_

# app.py

## Overview

This Lambda function confirms whether monitoring and auditing is implemented for all users.

It is triggered on a scheduled basis by AWS Config rules.
