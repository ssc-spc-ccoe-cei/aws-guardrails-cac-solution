_This readme file was created by AWS Bedrock: anthropic.claude-v2_

# app.py

## Overview

This Lambda function confirms the appropriate timezone has been set.

It is triggered on a scheduled basis by AWS Config rules.
