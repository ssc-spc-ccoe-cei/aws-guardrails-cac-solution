*This readme file was created by AWS Bedrock: anthropic.claude-v2*

# gc01_check_alerts_flag_misuse

## app.py

This is the main Lambda function for checking if root MFA is enabled.

### build_evaluation
- Builds an evaluation dictionary for AWS Config.
- Used to report compliance status.

## Testing
No testing code provided.

## Logging
No logging configuration provided.
