#!/bin/bash
app_list = $(find ./ -name "app.py")

for app